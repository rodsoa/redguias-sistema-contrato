<?php

namespace App\Domain\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface CustomerRepository.
 *
 * @package namespace App\Domain\Interfaces;
 */
interface CustomerRepository extends RepositoryInterface
{
    //
}
