<?php

namespace App\Domain\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface PhoneRepository.
 *
 * @package namespace App\Domain\Interfaces;
 */
interface PhoneRepository extends RepositoryInterface
{
    //
}
