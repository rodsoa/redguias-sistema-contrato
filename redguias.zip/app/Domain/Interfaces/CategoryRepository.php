<?php

namespace App\Domain\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface CategoryRepository.
 *
 * @package namespace App\Domain\Interfaces;
 */
interface CategoryRepository extends RepositoryInterface
{
    //
}
