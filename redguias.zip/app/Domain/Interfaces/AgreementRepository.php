<?php

namespace App\Domain\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface AgreementRepository.
 *
 * @package namespace App\Domain\Interfaces;
 */
interface AgreementRepository extends RepositoryInterface
{
    //
}
