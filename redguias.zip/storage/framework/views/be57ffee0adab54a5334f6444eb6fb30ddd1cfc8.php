Segue contrato em anexo.
<?php /**PATH /home/rodrigosoares/Projetos/pessoal/redguias/resources/views/agreements/email.blade.php ENDPATH**/ ?>