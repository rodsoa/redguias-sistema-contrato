<?php $__env->startSection('content_header'); ?>
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Novo Contrato</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="/">Início</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('agreements.index')); ?>">Contratos</a></li>
                    <li class="breadcrumb-item active"><a href="<?php echo e(route('agreements.create')); ?>">Novo</a></li>
                </ol>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('agreements.form',[
        'formTitle' => 'Formulário de cadastro',
        'isUpdate' => false,
        'action' => route('agreements.store'),
        'agreement' => null,
        'employees' => $employees,
        'customers' => $customers,
        'customer' => $customer,
        'customer_id' => $customer_id,
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rodrigosoares/Projetos/pessoal/redguias/resources/views/agreements/create.blade.php ENDPATH**/ ?>