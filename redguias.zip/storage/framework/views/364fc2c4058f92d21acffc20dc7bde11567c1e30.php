<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CONTRATO DE PRESTAÇÃO DE SERVIÇOS - REDGUIAS - <?php echo e(date('Y')); ?></title>

    <style type="text/css">
        * {
            font-family: Verdana, Arial, sans-serif;
        }

        table {
            font-size: x-small;
        }

        tfoot tr td {
            font-weight: bold;
            font-size: x-small;
        }

        .gray {
            background-color: lightgray
        }
    </style>

</head>
<body>

<table width="100%">
    <tr>
        <td valign="top">
            <img src="<?php echo e(public_path('img/logo.png')); ?>" alt="" width="150"/>
        </td>
        <td align="right" width="100%">
            <b>CONTRATO DE AUTORIZAÇÃO DE PRESTAÇÃO DE SERVIÇOS</b>
        </td>
    </tr>

    <tr>
        <p style="text-align: justify">
            A empresa / pessoa natural abaixo-assinada, contrata, em caráter irrevogável, obrigando-se herdeiros
            e sucessores, a <b>Editora RedGuias., CNPJ 08.956.117/0001-55</b>, estabelecida na Av. Paraná, 373 - Sala 05 - Centro
            CEP: 30.120-120 - Belo Horizonte - MG para publicar / veicular o anúncio abaixo no guia comercial  pelo de
            12 (doze) meses, estando ciente que o prazo de entrega do mesmo na praça é de no máximo 180 dias, a contar
            da autorização. Por estarem justos e contratados firmam o presente e elegem o foro de Belo Horizonte para dirimir
            eventual conflito.
        </p>
    </tr>
</table>

<hr>

<table width="100%">
    <tr style="margin-top: 12px">
        <td><strong>Razão Social:</strong> <?php echo e($agreement->customer->company_name); ?></td>
        <td><strong>Cidade:</strong> <?php echo e($agreement->customer->city); ?></td>
        <td><strong>Estado:</strong> <?php echo e($agreement->customer->uf); ?></td>
        <td><strong>CEP:</strong> <?php echo e($agreement->customer->zipcode); ?></td>
    </tr>

    <tr style="margin-top: 6px">
        <td><strong>CNPJ/CPF:</strong> <?php echo e($agreement->customer->cnpj); ?></td>
        <td><strong>Autorizante:</strong> <?php echo e($agreement->service_contractor); ?></td>
        <td><strong>Data:</strong> <?php echo e($agreement->created_at->format('d/m/Y')); ?></td>
        <td><strong>Edição:</strong> <?php echo e($agreement->version); ?></td>
    </tr>
</table>

<br/>

<table width="100%">
    <thead style="background-color: lightgray;">
    <tr>
        <th>Destaque</th>
        <th>Endereço Comercial</th>
        <th>Telefone</th>
    </tr>
    </thead>
    <tbody>

    <?php
        $categories = explode(',', $agreement->categories) ?? [];
        $addresses = explode(',', $agreement->comercial_address) ?? [];
        $phones = explode(',', $agreement->phones) ?? [];
    ?>

    <?php for($i = 0; $i < count($categories); $i++): ?>
        <tr>
            <td><?php echo e($categories[$i]); ?></td>
            <td align="center">
                <?php if(isset($addresses[$i])): ?>
                    <?php echo e($addresses[$i]); ?>

                <?php endif; ?>
            </td>
            <td align="right">
                <?php if(isset($phones[$i])): ?>
                    <?php echo e($phones[$i]); ?>

                <?php endif; ?>
            </td>
        </tr>
    <?php endfor; ?>
    </tbody>

    <!--tfoot>
    <tr>
        <td colspan="3"></td>
        <td align="right">Subtotal $</td>
        <td align="right">1635.00</td>
    </tr>
    <tr>
        <td colspan="3"></td>
        <td align="right">Tax $</td>
        <td align="right">294.3</td>
    </tr>
    <tr>
        <td colspan="3"></td>
        <td align="right">Total $</td>
        <td align="right" class="gray">$ 1929.3</td>
    </tr>
    </tfoot-->
</table>
<br>
<table width="100%">
    <thead style="background-color: lightgray;">
    <tr>
        <th colspan="7" align="center">Anúncio</th>
    </tr>
    <tr>
        <th>Faixa</th>
        <th>Cartão</th>
        <th>Logo</th>
        <th>1/4 Pag</th>
        <th>1/2 Pag</th>
        <th>1 Pag</th>
        <th>Local</th>
    </tr>
    </thead>
    <tbody>
        <?php
            $ads = ['faixa', 'cartão', 'logo', '1/4 pág', '1/2 pág', '1 pág'];
        ?>
        <tr>
            <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td align="center">
                    <?php if(in_array($ad, explode(",", optional($agreement)->advertisement))): ?>
                        X
                    <?php endif; ?>
                </td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <td align="center"><?php echo e($agreement->region); ?></td>
        </tr>

        <?php if($agreement->modifications): ?>
        <tr colspan="7">
            <td>
                <strong>Modificações:</strong> <?php echo e($agreement->modifications); ?>

            </td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>

<br>

<table width="100%">
    <tr>
        <td>
            <strong>SINAL R$:</strong>
            <i>
                <?php echo e(number_format($agreement->input_value, 2, ',', '.')); ?>

            </i>
        </td>
        <td>
            <strong>PARCELAS RESTANTES:</strong>
            <?php echo e($agreement->installments); ?>

            <strong> x R$</strong>
            <i>
                <?php echo e(number_format($agreement->installment_value, 2, ',', '.')); ?>

            </i>
        </td>
        <td>
            <strong>TOTAL R$:</strong>
            <i>
                <?php echo e(number_format($agreement->totalValue(), 2, ',', '.')); ?>

            </i>
        </td>
        <td>
            <strong>VENDEDOR:</strong> <?php echo e($agreement->employee->name); ?>

        </td>
    </tr>
</table>

<table with="100%">
    <?php
        $ads = ['credit_card' => 'CARTÃO', 'bank_check' => 'CHEQUE'];
    ?>
    <tr>
        <td>
            <strong>FORMA DE PAGAMENTO:</strong> <?php echo e($ads[$agreement->payment]); ?>

        </td>
        <td><strong>OBS</strong><?php echo e($agreement->observations); ?></td>
    </tr>
</table>

<table width="100%">
    <tr style="margin-top: 6px">
        <td><strong>ENTREGA:</strong> <?php echo e(optional(optional($agreement)->deadline)->format('d-m-Y')); ?></td>
    </tr>
</table>

<div style="text-align: center; margin-top: 10%">
    <img src="<?php echo e($agreement->signature); ?>" width="300">
    <br>
    <b>Assinatura</b>
</div>

</body>
</html>
<?php /**PATH /home/rodrigosoares/Projetos/pessoal/redguias/resources/views/agreements/agreement.blade.php ENDPATH**/ ?>