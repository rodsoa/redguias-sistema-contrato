Segue contrato em anexo.
<?php /**PATH /home3/redgui/public_html/resources/views/agreements/email.blade.php ENDPATH**/ ?>