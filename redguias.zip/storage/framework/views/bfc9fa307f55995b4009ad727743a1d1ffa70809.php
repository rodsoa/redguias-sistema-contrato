Segue contrato em anexo.
<?php /**PATH /home/vagrant/projetos/redguias/resources/views/agreements/email.blade.php ENDPATH**/ ?>