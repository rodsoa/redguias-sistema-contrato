<?php $__env->startSection('content_header'); ?>
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Contratos do sistema</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="/">Início</a></li>
                    <li class="breadcrumb-item active">Contratos</li>
                </ol>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title" style="padding-top: 6px">
                        Contratos
                        <small>
                            cadastrados no sistema
                        </small>
                    </h3>

                    <!--div class="float-right">
                        <a href="<?php echo e(route('agreements.create')); ?>" class="btn btn-sm btn-primary">
                            <i class="fa fa-fw fa-plus-circle"></i>
                            Adicionar
                        </a>
                    </div-->
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="table-responsive">
                                <table
                                    id="agreements-table"
                                    class="table table-bordered table-striped dataTable"
                                    role="grid"
                                    aria-describedby="example1_info">
                                    <thead>
                                    <tr role="row">
                                        <th>Data</th>
                                        <th>Cliente</th>
                                        <th>Edição</th>
                                        <th></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $agreements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agreement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($agreement->created_at->format('d-m-Y')); ?></td>
                                            <td><?php echo e($agreement->customer->company_name); ?></td>
                                            <td><?php echo e($agreement->version); ?></td>
                                            <td class="text-right">
                                                <div class="btn-group btn-group-sm">
                                                    <a href="<?php echo e(route('agreements.renew',['agreement' => $agreement->id])); ?>" type="button" class="btn btn-secondary"
                                                       title="renovar">
                                                        <i class="fa fa-fw fa-file-pdf"></i>
                                                        renovar
                                                    </a>
                                                    <a
                                                        type="button"
                                                        class="btn btn-secondary"
                                                        href="<?php echo e(route('agreements.edit', ['agreement' => $agreement->id])); ?>"
                                                        title="editar"
                                                    >
                                                        <i class="fa fa-fw fa-user-edit"></i>
                                                        editar
                                                    </a>
                                                    <a
                                                        type="button"
                                                        class="btn btn-secondary"
                                                        href="<?php echo e(route('agreements.download', ['agreement' => $agreement->id, 'preview' => 1])); ?>"
                                                        title="email"
                                                    >
                                                        <i class="fa fa-fw fa-mail-bulk"></i>
                                                        preview
                                                    </a>
                                                    <a
                                                        type="button"
                                                        class="btn btn-secondary"
                                                        href="<?php echo e(route('agreements.download', ['agreement' => $agreement->id, 'preview' => 0])); ?>"
                                                        title="email"
                                                    >
                                                        <i class="fa fa-fw fa-mail-bulk"></i>
                                                        email
                                                    </a>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                                                    <button
                                                        type="button"
                                                        class="btn btn-danger"
                                                        title="deletar"
                                                        onclick="deleteAgreement(<?php echo e($agreement->id); ?>)"
                                                    >
                                                        <i class="fa fa-fw fa-trash"></i>
                                                        deletar
                                                    </button>
                                                    <?php endif; ?>
                                                </div>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.card-body -->
            </div>
            <!-- /.card -->
        </div>
        <!-- /.col -->
    </div>

    <?php echo $__env->make('shared.delete_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $('#agreements-table').dataTable({
            responsive: true
        });

        function deleteAgreement(id) {
            if (confirm('Tem certeza dessa ação ?')) {
                const form = $('form[name="delete-form"]');
                form.attr('action', `/agreements/${id}`);
                form.submit();
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/redgui/public_html/resources/views/agreements/index.blade.php ENDPATH**/ ?>