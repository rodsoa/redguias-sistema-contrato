<form name="delete-form" action="" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
</form>
<?php /**PATH /home3/redgui/public_html/resources/views/shared/delete_form.blade.php ENDPATH**/ ?>