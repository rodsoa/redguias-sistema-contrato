<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="co-md-12 col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title" style="padding-top: 6px">
                        Ultimos Contratos
                        <small>
                            cadastrados no sistema
                        </small>
                    </h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="table-responsive">
                                <table
                                    id="agreements-table"
                                    class="table table-bordered table-striped dataTable"
                                    role="grid"
                                    aria-describedby="example1_info">
                                    <thead>
                                    <tr role="row">
                                        <th>Data</th>
                                        <th>Cliente</th>
                                        <th>Edição</th>
                                        <th></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $latests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agreement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($agreement->created_at->format('d-m-Y')); ?></td>
                                            <td><?php echo e($agreement->customer->company_name); ?></td>
                                            <td><?php echo e($agreement->created_at->format('Y')); ?></td>
                                            <td class="text-right">
                                                <div class="btn-group btn-group-sm">
                                                   <a
                                                        type="button"
                                                        class="btn btn-secondary"
                                                        href="<?php echo e(route('agreements.download', ['agreement' => $agreement->id, 'preview' => 1])); ?>"
                                                        title="email"
                                                    >
                                                        <i class="fa fa-fw fa-mail-bulk"></i>
                                                        preview
                                                    </a>
                                                    <a
                                                        type="button"
                                                        class="btn btn-secondary"
                                                        href="<?php echo e(route('agreements.download', ['agreement' => $agreement->id, 'preview' => 0])); ?>"
                                                        title="email"
                                                    >
                                                        <i class="fa fa-fw fa-mail-bulk"></i>
                                                        email
                                                    </a>
                                                </div>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.card-body -->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $('#agreements-table').dataTable({
            responsive: true
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/redgui/public_html/resources/views/home.blade.php ENDPATH**/ ?>