

<?php $__env->startSection('content_header'); ?>
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Clientes do sistema</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="#">Início</a></li>
                    <li class="breadcrumb-item active">Clientes</li>
                </ol>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title" style="padding-top: 6px">
                        Clientes
                        <small>
                            cadastrados no sistema
                        </small>
                    </h3>

                    <div class="float-right">
                        <a href="<?php echo e(route('customers.create')); ?>" class="btn btn-sm btn-primary">
                            <i class="fa fa-fw fa-plus-circle"></i>
                            Adicionar
                        </a>
                    </div>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="table-responsive">
                                <table
                                    id="customers-table"
                                    class="table table-bordered table-striped dataTable"
                                    role="grid"
                                    aria-describedby="example1_info">
                                    <thead>
                                    <tr role="row">
                                        <th>Cliente</th>
                                        <th>CPF / CNPJ</th>
                                        <!--th>Telefone</th>
                                        <th>Contato</th-->
                                        <th></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($customer->company_name); ?></td>
                                            <td><?php echo e($customer->cnpj); ?></td>
                                            <!--td><?php echo e($customer->phone_number); ?></td>
                                            <td><?php echo e($customer->contact_name); ?></td-->
                                            <td class="text-right">
                                                <div class="btn-group btn-group-sm">
                                                    <a href="<?php echo e(route('agreements.create', ['customer' => $customer->id])); ?>" type="button" class="btn btn-secondary"
                                                       title="contrato">
                                                        <i class="fa fa-fw fa-file-pdf"></i>
                                                       emitir contrato
                                                    </a>
                                                    <a
                                                        type="button"
                                                        class="btn btn-secondary"
                                                        href="<?php echo e(route('customers.edit', ['customer' => $customer->id])); ?>"
                                                        title="editar"
                                                    >
                                                        <i class="fa fa-fw fa-user-edit"></i>
                                                        editar
                                                    </a>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                                                    <button
                                                        type="button"
                                                        class="btn btn-danger"
                                                        title="deletar"
                                                        onclick="deleteCustomer(<?php echo e($customer->id); ?>)"
                                                    >
                                                        <i class="fa fa-fw fa-trash"></i>
                                                        deletar
                                                    </button>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.card-body -->
            </div>
            <!-- /.card -->
        </div>
        <!-- /.col -->
    </div>

    <?php echo $__env->make('shared.delete_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $('#customers-table').dataTable({
            responsive: true
        });

        function deleteCustomer(id) {
            if (confirm('Tem certeza dessa ação ?')) {
                const form = $('form[name="delete-form"]');
                form.attr('action', `/customers/${id}`);
                form.submit();
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/projetos/redguias/resources/views/customers/index.blade.php ENDPATH**/ ?>