<?php
    $btnSubmitLabel = $isUpdate ? 'Atualizar' : 'Cadastrar';
    $customer = $agreement ? $agreement->customer : ($customer_id ? $customer : null);
    $isUpdate = $renew ? false : $isUpdate;
    $btnSubmitLabel = $renew ? 'Renovar' : $btnSubmitLabel;
?>

<div class="row">
    <!-- left column -->
    <div class="col-md-12">
        <!-- general form elements -->
        <div class="card card-default">
            <div class="card-header">
                <h3 class="card-title"><?php echo e($formTitle); ?></h3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <form id="agreements-form" role="form" action="<?php echo e($action); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php if($isUpdate): ?>
                    <?php echo method_field('PUT'); ?>

                    <?php if($customer_id): ?>
                        <input type="hidden" name="customer_id" value="<?php echo e($customer_id); ?>">
                    <?php endif; ?>
                <?php endif; ?>

                <?php if($renew): ?>
                    <input type="hidden" name="customer_id" value="<?php echo e($agreement->customer_id); ?>">
                <?php endif; ?>
                <div class="card-body">
                    <div class="row">
                        <?php if(!$isUpdate && !$agreement): ?>
                            <div class="form-group col-sm-3">
                                <label for="customer">Cliente</label>
                                <select type="text" class="form-control" id="customer_id" name="customer_id" readonly>
                                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($c->id == $customer_id): ?>
                                            <option value="<?php echo e($c->id); ?>"  selected><?php echo e($c->company_name); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        <?php endif; ?>
                        <div class="form-group col-sm-2">
                            <label for="deadline">Entrega</label>
                            <input
                                type="text"
                                class="form-control date"
                                id="deadline"
                                placeholder="00/00/0000"
                                value="<?php echo e(optional(optional($agreement)->deadline)->format('d-m-Y')); ?>"
                                name="deadline"
                            >
                        </div>
                        <div class="form-group col-sm-2">
                            <label for="deadline">Edição</label>
                            <input
                                type="text"
                                class="form-control"
                                id="version"
                                placeholder="Edição"
                                value="<?php echo e(optional($agreement)->version); ?>"
                                name="version"
                                required
                            >
                        </div>

                            <div class="form-group col-sm-2">
                                <label for="zipcode">Cep</label>
                                <input type="text" class="form-control" id="zipcode" name="zipcode" placeholder="CEP" value="<?php echo e(optional(optional($customer))->zipcode); ?>" readonly>
                            </div>
                            <div class="form-group col-sm-1">
                                <label for="uf">Uf</label>
                                <input type="text" class="form-control" id="uf" name="uf" placeholder="UF" value="<?php echo e(optional(optional($customer))->uf); ?>" readonly>
                            </div>
                            <div class="form-group col-sm-2">
                                <label for="city">Cidade</label>
                                <input type="text" class="form-control" id="city" value="<?php echo e(optional(optional($customer))->city); ?>" readonly>
                            </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-sm-6">
                            <label for="company_name">Razação Social/Nome</label>
                            <input type="text" class="form-control disabled" id="company_name" placeholder="Nome do cliente/empresa" value="<?php echo e(optional($customer)->company_name); ?>" readonly>
                        </div>
                        <div class="form-group col-sm-3">
                            <label for="cnpj">CPF/CNPJ</label>
                            <input type="text" class="form-control cnpj disabled" id="cnpj" placeholder="CNPJ" value="<?php echo e(optional($customer)->cnpj); ?>" readonly>
                        </div>
                        <div class="form-group col-sm-3">
                            <label for="deadline">Data</label>
                            <input
                                type="text"
                                class="form-control date"
                                <?php if($isUpdate): ?>
                                    value="<?php echo e($agreement->created_at->format('d/m/Y')); ?>"
                                <?php else: ?>
                                    value="<?php echo e(\Carbon\Carbon::now()->format('d/m/Y')); ?>"
                                <?php endif; ?>
                                readonly
                            >
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-sm-3">
                            <label for="categories">Categorias</label>
                            <textarea class="form-control" id="categories" name="categories" placeholder="Categoria 1, Categoria 2, etc" required><?php echo e(optional($agreement)->categories); ?></textarea>
                        </div>
                        <div class="form-group col-sm-3">
                            <label for="address">Endereço Comercial</label>
                            <textarea class="form-control" id="address" placeholder="Endereço" name="comercial_address"><?php echo e(optional(optional($agreement))->comercial_address); ?></textarea>
                        </div>
                        <div class="form-group col-sm-3">
                            <label for="phones">Telefones</label>
                            <textarea class="form-control" id="phones" name="phones" placeholder="(xx) xxxx-xxxx, (xx) xxxx-xxxx, etc"><?php echo e(optional($agreement)->phones); ?></textarea>
                        </div>

                        <div class="col-sm-3" style="padding-left: 12px;padding-top: 38px">
                            <?php
                                $ads = ['faixa', 'cartão', 'logo', '1/4 pág', '1/2 pág', '1 pág'];
                            ?>
                            <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check float-left" style="margin-right: 12px">
                                    <input
                                        class="form-check-input"
                                        type="checkbox"
                                        value="<?php echo e($ad); ?>"
                                        id="<?php echo e($ad); ?>"
                                        name="advertisement[]"
                                        <?php if(in_array($ad, explode(",", optional($agreement)->advertisement))): ?>
                                            checked
                                        <?php endif; ?>
                                    >
                                    <label class="form-check-label" for="<?php echo e($ad); ?>">
                                        <?php echo e($ad); ?>

                                    </label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-sm-4">
                            <label for="employee_id">Vendedor</label>
                            <select type="text" class="form-control" id="employee_id" name="employee_id" <?php if($isUpdate): ?> readonly <?php endif; ?>>
                                <?php if($isUpdate): ?>
                                    <option value="<?php echo e(optional($agreement)->employee_id); ?>" selected ><?php echo e(optional($agreement)->employee->name); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e(auth()->user()->id); ?>" selected><?php echo e(auth()->user()->name); ?></option>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="form-group col-sm-4">
                            <label for="service_contractor">Autorizante</label>
                            <input
                                type="text"
                                class="form-control"
                                id="service_contractor"
                                name="service_contractor"
                                <?php if($isUpdate): ?>
                                    value="<?php echo e(optional($agreement)->service_contractor); ?>"
                                <?php else: ?>
                                    value="<?php echo e(optional($customer)->contact_name); ?>"
                                <?php endif; ?>
                                required
                            >
                        </div>
                        <div class="form-group col-sm-4">
                            <label for="region">Local</label>
                            <input type="text" class="form-control" id="region" name="region" value="<?php echo e(optional($agreement)->region); ?>" required>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-sm-6">
                            <label for="modifications">Modificações</label>
                            <input type="text" class="form-control" id="modifications" name="modifications" value="<?php echo e(optional($agreement)->modifications); ?>">
                        </div>
                        <div class="form-group col-sm-6">
                            <label for="observations">Observações</label>
                            <input type="text" class="form-control" id="observations" name="observations" value="<?php echo e(optional($agreement)->observations); ?>">
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-7">
                            <div class="row">
                                <div class="form-group col-sm-3">
                                    <?php
                                        $paymentForm = ['bank_check', 'credit_card'];
                                    ?>
                                    <label for="owner">Pagamento</label>
                                    <select type="text" class="form-control" id="payment" name="payment" required>
                                        <?php $__currentLoopData = $paymentForm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($form); ?>" <?php if($form == optional($agreement)->payment): ?> selected <?php endif; ?>><?php echo e($form == 'bank_check' ? 'Cheque' : 'Cartão'); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group col-sm-2">
                                    <label for="input_value" required>Sinal</label>
                                    <input type="text" class="form-control money2" id="input_value" name="input_value" value="<?php echo e(number_format(optional($agreement)->input_value, 2, ",", ".")); ?>">
                                </div>

                                <div class="form-group col-sm-2">
                                    <label for="installments" required>Parcelas</label>
                                    <input type="number" min="0" class="form-control" id="installments" name="installments" value="<?php echo e(optional($agreement)->installments); ?>" required>
                                </div>

                                <div class="form-group col-sm-2" required>
                                    <label for="installment_value">Valor</label>
                                    <input type="text" class="form-control money2" id="installment_value" name="installment_value" value="<?php echo e(number_format(optional($agreement)->installment_value, 2, ",", ".")); ?>">
                                </div>
                                <div class="form-group col-sm-2">
                                    <label for="installment_value">Total</label>
                                    <input type="text" class="form-control bg-warning money2" value="<?php echo e(number_format(optional($agreement)->totalValue(), 2, ",", ".")); ?>">
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-5">
                            <div class="row">
                                <div class="form-group col-sm-12">
                                    <label>Assinatura</label>
                                    <canvas
                                        class="form-control"
                                        style="min-height: 120px;touch-action: none;"
                                    ></canvas>
                                    <input type="hidden" id="signature" name="signature" value="<?php echo e(optional($agreement)->signature); ?>">
                                    <input type="hidden" id="sendMail" name="sendMail" value=0>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                    <div class="float-right">
                        <button type="button" class="btn btn-default" onclick="clearSignaturePad()">Limpar Assinatura</button>
                        <button type="button" class="btn btn-primary" onclick="submitForm()"><?php echo e($btnSubmitLabel); ?></button>
                        <button type="button" class="btn btn-primary" onclick="submitForm(true)"><?php echo e($btnSubmitLabel); ?> e enviar</button>
                        <a role="button" class="btn btn-danger" href="<?php echo e(route('agreements.index')); ?>">Cancelar</a>
                    </div>
                </div>
            </form>
        </div>
        <!-- /.card -->
    </div>
    <!--/.col (left) -->
    <!-- right column -->
</div>

<?php $__env->startSection("css"); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("js"); ?>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/signature_pad@3.0.0-beta.3/dist/signature_pad.umd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-mask-plugin@1.14.16/dist/jquery.mask.min.js" integrity="sha256-Kg2zTcFO9LXOc7IwcBx1YeUBJmekycsnTsq2RuFHSZU=" crossorigin="anonymous"></script>
    <script>
        var canvas = document.querySelector("canvas");
        var signaturePad = new SignaturePad(canvas);

        $('#customer_id').change(function(){
           location.href="/agreements/create?customer="+$(this).val();
        });

        if ( $('#signature').val() != null ||  $('#signature') != '') {
            signaturePad.fromDataURL($('#signature').val());
        }

        /**
         * MASCARAS
         */
        $('.date').mask('00/00/0000');
        $('.cep').mask('00000-000');
        $('.phone').mask('0000-0000');
        $('.phone_with_ddd').mask('(00) 0000-0000');
        $('.cnpj').mask('00.000.000/0000-00', {reverse: true});
        $('.money2').mask("#.##0,00", {reverse: true});

        // Clears the canvas
        function clearSignaturePad() {
            signaturePad.clear();
        }

        // Submit Form with signature value
        function submitForm(sendMail = false) {
            if (!signaturePad.isEmpty()) {
                $('#signature').val(
                    signaturePad.toDataURL()
                );
            }

            if(
                !$('input[name="advertisement[]"').is(':checked')
            ) {
                alert('Campo de anúncio precisa ser marcado ao menos um!');
            }

            if ( $('#agreements-form').valid() ) {

                if (sendMail) {
                    $('#sendMail').val(1);
                } else {
                    $('#sendMail').val(0);
                }

                $('#agreements-form').submit();
            } else {
                alert('Existem campos a serem preenchidos no formulário');
            }
        }
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/vagrant/projetos/redguias/resources/views/agreements/form.blade.php ENDPATH**/ ?>