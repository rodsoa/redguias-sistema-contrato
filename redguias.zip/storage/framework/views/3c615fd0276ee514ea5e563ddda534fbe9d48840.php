

<?php $__env->startSection('content_header'); ?>
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Edição de Cliente</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="/">Início</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('customers.index')); ?>">Clientes</a></li>
                    <li class="breadcrumb-item active"><a href="<?php echo e(route('customers.edit', ['customer' => $customer->id])); ?>">Edição</a></li>
                </ol>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('customers.form',[
        'formTitle' => 'Formulário de cadastro',
        'isUpdate' => true,
        'customer' => $customer,
        'action' => route('customers.update', ['customer' => $customer->id])
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/projetos/redguias/resources/views/customers/edit.blade.php ENDPATH**/ ?>