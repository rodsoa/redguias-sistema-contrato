<form name="delete-form" action="" method="POST">
    @csrf
    @method('DELETE')
</form>
